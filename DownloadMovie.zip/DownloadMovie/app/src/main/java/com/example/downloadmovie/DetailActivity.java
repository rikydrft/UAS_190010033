package com.example.downloadmovie;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        TextView tvnamamovie=findViewById(R.id.tvJudul);
        TextView tvdeskripsi=findViewById(R.id.tvDesk);
        ImageView ivmovie=findViewById(R.id.ivMovie);
        tvnamamovie.setText(getIntent().getStringExtra("nama"));
        tvdeskripsi.setText(getIntent().getStringExtra("deskripsi"));

        String url= getIntent().getStringExtra("gambar");
        Glide.with(this)
                .load(url)
                .override(900, 800)
                .into(ivmovie);
    }
}
package com.example.downloadmovie;

public class Movie {
    private String nama;
    private String deskripsi;
    private String gambar;

    public Movie(String datanama, String datadesk, String datagambar){
        nama=datanama;
        deskripsi=datadesk;
        gambar=datagambar;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getGambar() {
        return gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }
}

package com.example.downloadmovie;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MovieViewHolder> {
    private Context context;
    private ArrayList<Movie> movies;

    public MovieAdapter(Context mcontext, ArrayList<Movie> menumovies){
        context=mcontext;
        movies=menumovies;

    }

    @NonNull
    @Override
    public MovieViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_movie,parent,false);
        return new MovieViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MovieViewHolder holder, int position) {
        Movie moviebaru= movies.get(position);
        String gambarbaru= moviebaru.getGambar();
        String Nama= moviebaru.getNama();
        String Deskripsi= moviebaru.getDeskripsi();

        Glide
                .with(context)
                .load(gambarbaru)
                .centerCrop()
                .into(holder.imdata);

        holder.tvnamadata.setText(Nama);
        holder.tvdeskdata.setText(Deskripsi);
        holder.btnpindah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pindah = new Intent(v.getContext(),DetailActivity.class);
                pindah.putExtra("nama",moviebaru.getNama());
                pindah.putExtra("deskripsi",moviebaru.getDeskripsi());
                pindah.putExtra("gambar",moviebaru.getGambar());
                v.getContext().startActivity(pindah);
            }
        });

    }

    @Override
    public int getItemCount() {
        return movies.size();
    }

    public class MovieViewHolder extends RecyclerView.ViewHolder {
        public ImageView imdata;
        public TextView tvnamadata;
        public TextView tvdeskdata;
        public Button btnpindah;

        public MovieViewHolder(@NonNull View itemView) {
            super(itemView);
            imdata=itemView.findViewById(R.id.IvGambar);
            tvnamadata=itemView.findViewById(R.id.TvTextJudul);
            tvdeskdata=itemView.findViewById(R.id.TvTextDeskripsi);
            btnpindah=itemView.findViewById(R.id.BtnDown);
        }
    }
}
